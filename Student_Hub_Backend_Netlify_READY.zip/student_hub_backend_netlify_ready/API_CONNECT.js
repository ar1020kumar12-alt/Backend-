// Student Hub Netlify -> Render connector
// Replace this URL with your Render backend URL after deployment.
const STUDENT_HUB_API = "https://YOUR-RENDER-SERVICE.onrender.com";

async function studentHubAPI(path, options = {}) {
  const response = await fetch(STUDENT_HUB_API + path, {
    ...options,
    headers: { "Content-Type": "application/json", ...(options.headers || {}) }
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.detail || "Backend request failed");
  return data;
}
